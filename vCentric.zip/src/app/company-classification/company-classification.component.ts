import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-classification',
  templateUrl: './company-classification.component.html',
  styleUrls: ['./company-classification.component.css']
})
export class CompanyClassificationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
